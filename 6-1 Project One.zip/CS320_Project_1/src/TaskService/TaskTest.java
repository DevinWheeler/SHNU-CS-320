package TaskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskTest {

    @Test
    public void testTaskCreation() {
        Task task = new Task("12345", "Test Task", "This is a test task description.");
        assertEquals("12345", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test task description.", task.getDescription());
    }

    @Test
    public void testSetName() {
        Task task = new Task("12345", "Test Task", "This is a test task description.");
        task.setName("New Name");
        assertEquals("New Name", task.getName());
    }

    @Test
    public void testSetDescription() {
        Task task = new Task("12345", "Test Task", "This is a test task description.");
        task.setDescription("New Description");
        assertEquals("New Description", task.getDescription());
    }

    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Test Task", "This is a test task description.");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Test Task", "This is a test task description.");
        });
    }

    @Test
    public void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "This is a test task description.");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "This name is way too long to be valid", "This is a test task description.");
        });
    }

    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Test Task", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Test Task", "This description is way too long to be valid and should throw an exception.");
        });
    }

    @Test
    public void testSetNameWithInvalidValue() {
        Task task = new Task("12345", "Test Task", "This is a test task description.");
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("This name is way too long to be valid");
        });
    }

    @Test
    public void testSetDescriptionWithInvalidValue() {
        Task task = new Task("12345", "Test Task", "This is a test task description.");
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("This description is way too long to be valid and should throw an exception.");
        });
    }
}
