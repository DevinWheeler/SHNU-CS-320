package TaskService;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> tasks;

    public TaskService() {
        tasks = new HashMap<>();
    }

    //add a valid task
    public void addTask(String taskId, String name, String description) {
        if (!isValidString(taskId, 10) || tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Invalid or duplicate task ID");
        }
        if (!isValidString(name, 20)) {
            throw new IllegalArgumentException("Invalid task name");
        }
        if (!isValidString(description, 50)) {
            throw new IllegalArgumentException("Invalid task description");
        }

        Task task = new Task(taskId, name, description);
        tasks.put(task.getTaskId(), task);
    }

    //deletes a task by id
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }
        tasks.remove(taskId);
    }

    
    //updates a task name by id
    public void updateTaskName(String taskId, String name) {
        if (!isValidString(name, 20)) {
            throw new IllegalArgumentException("Invalid task name");
        }
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }
        task.setName(name);
    }

    
    //update task description by id
    public void updateTaskDescription(String taskId, String description) {
        if (!isValidString(description, 50)) {
            throw new IllegalArgumentException("Invalid task description");
        }
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }
        task.setDescription(description);
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
    
    private boolean isValidString(String value, int maxLength) {
        return value != null && value.length() <= maxLength;
    }

}

