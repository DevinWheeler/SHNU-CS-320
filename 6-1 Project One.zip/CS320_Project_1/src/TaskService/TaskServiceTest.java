package TaskService;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
	
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        taskService.addTask("12345", "Test Task", "This is a test task description.");
        Task task = taskService.getTask("12345");
        assertNotNull(task);
        assertEquals("12345", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test task description.", task.getDescription());
    }

    @Test
    public void testAddDuplicateTask() {
        taskService.addTask("12345", "Test Task", "This is a test task description.");
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask("12345", "Another Test Task", "This is another test task description.");
        });
    }

    @Test
    public void testAddTaskInvalidId() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(null, "Test Task", "This is a test task description.");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask("12345678901", "Test Task", "This is a test task description.");
        });
    }

    @Test
    public void testAddTaskInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask("12345", null, "This is a test task description.");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask("12345", "This name is way too long to be valid", "This is a test task description.");
        });
    }

    @Test
    public void testAddTaskInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask("12345", "Test Task", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask("12345", "Test Task", "This description is way too long to be valid and should throw an exception.");
        });
    }

    @Test
    public void testDeleteTask() {
        taskService.addTask("12345", "Test Task", "This is a test task description.");
        taskService.deleteTask("12345");
        assertNull(taskService.getTask("12345"));
    }

    @Test
    public void testDeleteNonExistentTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.deleteTask("54321");
        });
    }

    @Test
    public void testUpdateTaskName() {
        taskService.addTask("12345", "Test Task", "This is a test task description.");
        taskService.updateTaskName("12345", "New Task Name");
        assertEquals("New Task Name", taskService.getTask("12345").getName());
    }

    @Test
    public void testUpdateTaskInvalidName() {
        taskService.addTask("12345", "Test Task", "This is a test task description.");
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskName("12345", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskName("12345", "This name is way too long to be valid");
        });
    }

    @Test
    public void testUpdateTaskDescription() {
        taskService.addTask("12345", "Test Task", "This is a test task description.");
        taskService.updateTaskDescription("12345", "New Task Description");
        assertEquals("New Task Description", taskService.getTask("12345").getDescription());
    }

    @Test
    public void testUpdateTaskInvalidDescription() {
        taskService.addTask("12345", "Test Task", "This is a test task description.");
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskDescription("12345", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskDescription("12345", "This description is way too long to be valid and should throw an exception.");
        });
    }

    @Test
    public void testUpdateNonExistentTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskName("54321", "New Task Name");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskDescription("54321", "New Task Description");
        });
    }
}
