package TaskService;


public class Task {
	
	/* initialize variables*/
    private final String taskId;
    private String name;
    private String description;

    /* initialize Task */
    public Task(String taskId, String name, String description) {
    	
    	if (!isValidString(taskId, 10)){
            throw new IllegalArgumentException("Invalid or duplicate task ID");
        }
        if (!isValidString(name, 20)) {
            throw new IllegalArgumentException("Invalid task name");
        }
        if (!isValidString(description, 50)) {
            throw new IllegalArgumentException("Invalid task description");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    /* Setters and getters*/
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
    	if (!isValidString(name, 20)) {
            throw new IllegalArgumentException("Invalid task name");
        }
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
    	if (!isValidString(description, 50)) {
            throw new IllegalArgumentException("Invalid task description");
        }
        this.description = description;
    }
    
    private boolean isValidString(String value, int maxLength) {
        return value != null && value.length() <= maxLength;
    }
}

