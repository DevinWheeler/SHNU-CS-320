package AppointmentService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

public class AppointmentTest {
private LocalDate futureDate;

    @BeforeEach
    public void setUp() {
        futureDate = LocalDate.now().plusDays(1); // 1 day into the future
    }

    @Test
    public void testValidAppointment() {
        Appointment appointment = new Appointment("1234567890", futureDate, "Valid description");
        
        assertEquals("1234567890", appointment.getAppointmentID());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Valid description", appointment.getDescription());
    }

    @Test
    public void testInvalidAppointmentID() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Description");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Description");
        });
    }

    @Test
    public void testInvalidAppointmentDate() {
        LocalDate pastDate = LocalDate.now().minusDays(1);
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", pastDate, "Description");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", null, "Description");
        });
    }

    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", futureDate, null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", futureDate, "This description is way too long and exceeds the fifty characters limit.");
        });
    }
}
