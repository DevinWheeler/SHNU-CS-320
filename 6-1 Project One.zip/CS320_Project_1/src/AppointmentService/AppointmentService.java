package AppointmentService;

import java.util.HashMap;
import java.util.Map;
import java.time.LocalDate;

public class AppointmentService {
private final Map<String, Appointment> appointments = new HashMap<>();

//could add checks for the strings but got lazy, it will get handled when being added
public void addAppointment(String appointmentID, LocalDate appointmentDate, String description) {
  if (appointments.containsKey(appointmentID)) {
      throw new IllegalArgumentException("Appointment ID already exists");
  }
  Appointment newAppointment = new Appointment(appointmentID, appointmentDate, description);
  appointments.put(appointmentID, newAppointment);
}

public void deleteAppointment(String appointmentID) {
  if (!appointments.containsKey(appointmentID)) {
      throw new IllegalArgumentException("Appointment ID does not exist");
  }
  appointments.remove(appointmentID);
}

public Appointment getAppointment(String appointmentID) {
  return appointments.get(appointmentID);
}
}