package AppointmentService;

import java.time.LocalDate;

public class Appointment {
private final String appointmentID;
private final LocalDate appointmentDate;
private final String description;


//create Appointment
public Appointment(String appointmentID, LocalDate appointmentDate, String description) {
 if (appointmentID == null || appointmentID.length() > 10) {
     throw new IllegalArgumentException("Invalid appointment ID");
 }
 if (appointmentDate == null || appointmentDate.isBefore(LocalDate.now())) {
     throw new IllegalArgumentException("Invalid appointment date");
 }
 if (description == null || description.length() > 50) {
     throw new IllegalArgumentException("Invalid description");
 }

 this.appointmentID = appointmentID;
 this.appointmentDate = appointmentDate;
 this.description = description;
}

//create getters -- However no setters where added as no way was described to use them at this time

public String getAppointmentID() {
 return appointmentID;
}

public LocalDate getAppointmentDate() {
 return appointmentDate;
}

public String getDescription() {
 return description;
}
}

