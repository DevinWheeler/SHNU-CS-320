package AppointmentService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

public class AppointmentServiceTest {
private AppointmentService service;
private LocalDate futureDate;

@BeforeEach
public void setUp() {
    service = new AppointmentService();
    futureDate = LocalDate.now().plusDays(1); // 1 day into the future
}

@Test
public void testAddValidAppointment() {
    service.addAppointment("1234567890", futureDate, "Test Description");
    Appointment appointment = service.getAppointment("1234567890");
    
    assertNotNull(appointment);
    assertEquals("1234567890", appointment.getAppointmentID());
    assertEquals(futureDate, appointment.getAppointmentDate());
    assertEquals("Test Description", appointment.getDescription());
}

@Test
public void testAddDuplicateAppointmentID() {
    service.addAppointment("1234567890", futureDate, "Test Description");
    assertThrows(IllegalArgumentException.class, () -> {
        service.addAppointment("1234567890", futureDate, "Another Description");
    });
}

@Test
public void testInvalidAppointmentID() {
    assertThrows(IllegalArgumentException.class, () -> {
        service.addAppointment(null, futureDate, "Description");
    });

    assertThrows(IllegalArgumentException.class, () -> {
        service.addAppointment("12345678901", futureDate, "Description");
    });
}

@Test
public void testInvalidAppointmentDate() {
    LocalDate pastDate = LocalDate.now().minusDays(1);
    
    assertThrows(IllegalArgumentException.class, () -> {
        service.addAppointment("1234567890", pastDate, "Description");
    });

    assertThrows(IllegalArgumentException.class, () -> {
        service.addAppointment("1234567890", null, "Description");
    });
}

@Test
public void testInvalidDescription() {
    assertThrows(IllegalArgumentException.class, () -> {
        service.addAppointment("1234567890", futureDate, null);
    });

    assertThrows(IllegalArgumentException.class, () -> {
        service.addAppointment("1234567890", futureDate, "This description is way too long and exceeds the fifty characters limit.");
    });
}

@Test
public void testDeleteExistingAppointment() {
    service.addAppointment("1234567890", futureDate, "Test Description");
    service.deleteAppointment("1234567890");
    assertNull(service.getAppointment("1234567890"));
}

@Test
public void testDeleteNonExistentAppointment() {
    assertThrows(IllegalArgumentException.class, () -> {
        service.deleteAppointment("nonexistent");
    });
}
}