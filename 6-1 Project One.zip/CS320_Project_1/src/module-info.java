/**
 * 
 */
/**
 * 
 */
module CS320_Project_1 {
	requires org.junit.jupiter.api;
}