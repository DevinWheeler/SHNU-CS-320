package ContactService;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts = new HashMap<>();

    /*Check if contact exists and adds if new */
    public void addContact(String contactId, String firstName, String lastName, String phone, String address) {
        if (contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        Contact contact = new Contact(contactId, firstName, lastName, phone, address);
        contacts.put(contactId, contact);
    }
    
    /*Check if contact exists and deletes if it does */
    public void deleteContact(String contactId) {
    	checkContactExists(contactId);
        contacts.remove(contactId);
    }

    /*Updates First name if valid */
    public void updateContactFirstName(String contactId, String firstName) {
    	 Contact contact = checkContactExists(contactId);
        if (!isValidString(firstName, 10)) {
            throw new IllegalArgumentException("Invalid first name");
        }
        contact.setFirstName(firstName);
    }

    /*Updates Last name if valid */
    public void updateContactLastName(String contactId, String lastName) {
    	 Contact contact = checkContactExists(contactId);
        if (!isValidString(lastName, 10)) {
            throw new IllegalArgumentException("Invalid last name");
        }
        contact.setLastName(lastName);
    }

    /*Updates Phone if valid */
    public void updateContactPhone(String contactId, String phone) {
    	 Contact contact = checkContactExists(contactId);
        if (!isValidString(phone, 10)) {
            throw new IllegalArgumentException("Invalid phone number");
        }
        contact.setPhone(phone);
    }

    /*Updates Address if valid */
    public void updateContactAddress(String contactId, String address) {
    	 Contact contact = checkContactExists(contactId);
        if (!isValidString(address, 30)) {
            throw new IllegalArgumentException("Invalid address");
        }
        contact.setAddress(address);
    }
    
 
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }

    private Contact checkContactExists(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID does not exist");
        }
        return contacts.get(contactId);
    }
    
    private boolean isValidString(String value, int maxLength) {
        return value != null && value.length() <= maxLength;
    }
}