package ContactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testContactCreationSuccess() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Street");
        assertEquals("12345", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Street", contact.getAddress());
    }

    @Test
    public void testInvalidContactIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Doe", "1234567890", "123 Street");
        });
    }
    
    @Test
    public void testInvalidContactIdLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Street");
        });
    }
    
    @Test
    public void testInvalidFirstNameNull() {
       assertThrows(IllegalArgumentException.class, () -> {
            new Contact("55555", null, "Doe", "1234567890", "123 Street");
        });
    }
    
    @Test
    public void testInvalidFirstNameLong() {
       assertThrows(IllegalArgumentException.class, () -> {
            new Contact("55555", "JohnJohnJohn", "Doe", "1234567890", "123 Street");
        });
    }
    
    @Test
    public void testInvalidLastNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("55555", "John", null, "1234567890", "123 Street");
        });
    }
    
    @Test
    public void testInvalidLastNameLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("55555", "John", "DoeDoeDoeDoe", "1234567890", "123 Street");
        });
    }
    
    @Test
    public void testInvalidPhoneNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("55555", "John", "Doe", null, "123 Street");
        });
    }
    
    @Test
    public void testInvalidPhoneLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("55555", "John", "Doe", "12345678901", "123 Street");
        });
    }
    
    @Test
    public void testInvalidAddressNull() {
       assertThrows(IllegalArgumentException.class, () -> {
            new Contact("55555", "John", "Doe", "1234567890", null);
        });
    }
    
    @Test
    public void testInvalidAddressLong() {
       assertThrows(IllegalArgumentException.class, () -> {
            new Contact("55555", "John", "Doe", "1234567890", "123456789012345678901234567890 Street");
        });
    }

    @Test
    public void testSetFirstName() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Street");
        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());
        
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName("JaneJaneJane");
        });
    }

    @Test
    public void testSetLastName() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Street");
        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());
        
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName("SmithSmithSmith");
        });
    }

    @Test
    public void testSetPhone() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Street");
        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone());
        
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone("09876543210");
        });
    }

    @Test
    public void testSetAddress() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Street");
        contact.setAddress("456 Avenue");
        assertEquals("456 Avenue", contact.getAddress());
        
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress("456 Avenue with a very long address that exceeds the limit");
        });
    }
}
