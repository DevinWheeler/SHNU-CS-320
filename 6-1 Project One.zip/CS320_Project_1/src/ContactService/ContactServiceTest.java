package ContactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService service;
    private Contact contact;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
        contact = new Contact("12345", "John", "Doe", "1234567890", "123 Street");
        service.addContact(contact.getContactId(), contact.getFirstName(), contact.getLastName(), contact.getPhone(), contact.getAddress());
    }

    @Test
    public void testAddContact() {
        Contact newContact = new Contact("54321", "Jane", "Smith", "0987654321", "456 Avenue");
        service.addContact(newContact.getContactId(), newContact.getFirstName(), newContact.getLastName(), newContact.getPhone(), newContact.getAddress());
        Contact retrievedContact = service.getContact("54321");
        assertEquals("54321", retrievedContact.getContactId());
        assertEquals("Jane", retrievedContact.getFirstName());
        assertEquals("Smith", retrievedContact.getLastName());
        assertEquals("0987654321", retrievedContact.getPhone());
        assertEquals("456 Avenue", retrievedContact.getAddress());
    }

    @Test
    public void testDeleteContact() {
        service.deleteContact(contact.getContactId());
        assertNull(service.getContact(contact.getContactId()));
    }

    @Test
    public void testDeleteNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("nonexistent");
        });
    }

    @Test
    public void testUpdateContactFirstName() {
        service.updateContactFirstName(contact.getContactId(), "Jane");
        assertEquals("Jane", service.getContact(contact.getContactId()).getFirstName());
    }

    @Test
    public void testUpdateContactFirstNameInvalid() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateContactFirstName(contact.getContactId(), "JaneJaneJane"); // This line should be counted
        });
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateContactFirstName(contact.getContactId(), null); // This line should be counted
        });
    }

    @Test
    public void testUpdateContactLastName() {
        service.updateContactLastName(contact.getContactId(), "Smith");
        assertEquals("Smith", service.getContact(contact.getContactId()).getLastName());
    }

    @Test
    public void testUpdateContactLastNameInvalid() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateContactLastName(contact.getContactId(), "SmithSmithSmith");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateContactLastName(contact.getContactId(), null);
        });
    }

    @Test
    public void testUpdateContactPhone() {
        service.updateContactPhone(contact.getContactId(), "0987654321");
        assertEquals("0987654321", service.getContact(contact.getContactId()).getPhone());
    }

    @Test
    public void testUpdateContactPhoneInvalid() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateContactPhone(contact.getContactId(), "09876543210");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateContactPhone(contact.getContactId(), null);
        });
    }

    @Test
    public void testUpdateContactAddress() {
        service.updateContactAddress(contact.getContactId(), "456 Avenue");
        assertEquals("456 Avenue", service.getContact(contact.getContactId()).getAddress());
    }

    @Test
    public void testUpdateContactAddressInvalid() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateContactAddress(contact.getContactId(), "456 Avenue with a very long address that exceeds the limit");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateContactAddress(contact.getContactId(), null);
        });
    }

    @Test
    public void testAddDuplicateContactId() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact.getContactId(), "Jane", "Smith", "0987654321", "456 Avenue");
        });
    }
}
